# Entscheidungslog

Jede Entscheidung mit echter Alternative. Wo es keine Alternative gab, war es
keine Entscheidung und steht nicht hier.

**Zur Datierung, offen gesagt:** dieses Log wurde ab E19 mit dem jeweiligen
Tagesdatum geführt. E01–E18 sind in den Arbeitssitzungen davor gefallen und
hier nachträglich eingetragen. Sie tragen deshalb keine erfundenen Datumsangaben,
sondern die Phase, in der sie fielen. Der einzige datumsgenau belegte Zeitpunkt
in dieser Gruppe ist der Datenabruf am **25.09.2026, 15:55** — er steht im
Schnappschuss selbst (`searchDate`), nicht in einer Notiz.

Aufbau jedes Eintrags: Situation · Alternativen · Entscheidung · Begründung ·
Revisionspunkt (woran man erkennt, dass sie falsch war).

| Nr | Phase | Entscheidung | Status |
|---|---|---|---|
| [E01](#e01) | Themenwahl | Wasserentnahme-Ampel Leitha als Thema | verworfen (E02) |
| [E02](#e02) | Themenwahl | Wechsel auf Kraftwerk Greifenstein | verworfen (E03) |
| [E03](#e03) | Themenwahl | Wechsel auf Mietportfolio Wien | gültig |
| [E04](#e04) | Zuschnitt | Entscheider ist der Vermieter, nicht die Behörde | gültig |
| [E05](#e05) | Zuschnitt | Einkommen als Annahme- und Risikogröße, nicht als Preisargument | gültig |
| [E06](#e06) | Datenzugriff | manuelle Beschaffung statt Crawler | gültig |
| [E07](#e07) | Datenzugriff | `__NEXT_DATA__` parsen statt HTML-Klassen | gültig |
| [E08](#e08) | Datenzugriff | Abrufzeit vom Server, nicht von der Parser-Uhr | gültig |
| [E09](#e09) | Datenzugriff | PLZ aus dem Dateinamen als Pflichtprüfung | gültig |
| [E10](#e10) | Datenzugriff | Selbstprüfendes Beschaffungsskript statt Anleitung | gültig |
| [E11](#e11) | Datenschutz | Allowlist statt Blocklist, im Code statt im Prompt | gültig |
| [E12](#e12) | Datenmodell | SQLite statt MySQL | gültig |
| [E13](#e13) | Datenmodell | Faktentabelle append-only, Schlüssel (Schnappschuss, Inserat) | gültig |
| [E14](#e14) | Datenmodell | PLZ als Fremdschlüssel, Bezirke aus der Konfiguration | gültig |
| [E15](#e15) | Datenmodell | Datenbank bei jedem Lauf neu bauen | gültig |
| [E16](#e16) | Analyse | Median über Fensterfunktion, Fallzahl an jeder Zeile | gültig |
| [E17](#e17) | Modell | Gegenkraft ins Entscheidungsmodell | gültig |
| [E18](#e18) | Modell | Fixpunkt mit Dämpfung statt Einmalrechnung | gültig |
| [E19](#e19) | Aufräumen | PII-Logik in `clean.py`, Allowlist in `config.py` | gültig |
| [E20](#e20) | Zusammenarbeit | GitHub-Repository als gemeinsame Arbeitsfläche | gültig |
| [E21](#e21) | Datenschutz | redigierte Schnappschüsse im Repository, Originale nur lokal | gültig |
| [E22](#e22) | Datenzugriff | `verticalId` als erste Prüfung in Gate 1 | gültig |
| [E23](#e23) | Dokumentation | ein Dokument je Schritt statt zweier überlappender | gültig |
| [E24](#e24) | Zusammenarbeit | Claude bleibt Autor der Commits | gültig |
| [E25](#e25) | Repository | `data/raw/` wird committet — Abweichung von der Vorgabe | gültig |
| [E26](#e26) | Repository | Datenbank committet, dafür Uhrzeit aus der Datenbank entfernt | gültig |

---

## E01 {#e01}
### Wasserentnahme-Ampel für die Leitha als Projektthema
**Phase:** Themenwahl

**Situation.** Gesucht war ein Thema, zu dem es echte, laufend aktualisierte
österreichische Daten gibt und eine Entscheidung, die jemand tatsächlich trifft.

**Alternativen.**
1. Wasserentnahme-Ampel für einen Fluss (eHYD-Pegel + Trockenheitsindex).
2. Strommarkt-Thema aus einem früheren Projekt.
3. Ein Thema mit fertigen Kaggle-Daten.

**Entscheidung.** Variante 1.

**Begründung.** (3) fällt am Bewertungskriterium „existieren die Quellen
wirklich" durch — vorbereinigte Wettbewerbsdaten sind genau der Fall, den die
Lehrveranstaltung ausschließt. (2) war vorhanden, aber ohne
Entscheidungsträger.

**Was schiefging.** Die Pegeldaten ließen sich nicht verlässlich automatisiert
abrufen: das Download-Muster, das ich für eHYD angenommen hatte
(`MessstellenExtraData/owf?id=…&file=…`), lieferte im Test 404. Ich hatte es
aus einem Drittanbieter-Beispiel übernommen und nicht selbst geprüft. Das ist in
`02_schritt1_datenzugriff.md` als Irrtum protokolliert.

**Revisionspunkt.** Erledigt durch E02.

---

## E02 {#e02}
### Wechsel auf das Donaukraftwerk Greifenstein
**Phase:** Themenwahl

**Situation.** Das Wasserthema sollte bleiben, aber mit einer Entscheidung, die
eine benennbare Stelle trifft.

**Alternativen.**
1. Kraftwerksbetreiber entscheidet über Stauziel.
2. Wasserrechtsbehörde entscheidet über die Regel, innerhalb der der Betreiber
   entscheidet.

**Entscheidung.** Variante 2, auf ausdrücklichen Wunsch.

**Begründung.** Der Betreiber optimiert innerhalb gegebener Grenzen — das ist
Rechnen, keine Entscheidung mit Optionen. Die Behörde entscheidet über die
Grenzen selbst und hat konkurrierende Ziele (Energie, Schifffahrt, Ökologie).

**Was schiefging.** Zwei Dinge, beide dokumentiert.
Erstens hatte das Modell keine Gegenkraft: die Empfehlung war immer das
größtmögliche Stauzielband (→ E17). Zweitens war das Goldset für die
LLM-Auswertung ungültig, weil ich die `rohtext`-Felder aus Suchtreffer-Snippets
rekonstruiert hatte statt wörtlich aus den PDFs zu kopieren. Ein Eval gegen
meine eigene Formulierung misst nichts.

**Revisionspunkt.** Erledigt durch E03. Die Lehre aus dem Goldset gilt weiter:
Referenzantworten werden wörtlich aus dem Quelldokument kopiert, mit Seitenzahl.

---

## E03 {#e03}
### Wechsel auf das Mietportfolio Wien
**Phase:** Themenwahl

**Situation.** Nach zwei Anläufen fehlte immer noch eine Datenquelle, die sich
regelmäßig und ohne Bastelei neu abrufen lässt — das Kernstück einer Pipeline,
die Datenänderungen überleben soll.

**Alternativen.**
1. Beim Wasserthema bleiben und die Beschaffung reparieren.
2. Auf ein Thema wechseln, dessen Marktpreisniveau laufend beobachtbar ist:
   Mietinserate in drei Wiener Bezirken.

**Entscheidung.** Variante 2.

**Begründung.** Beobachtbarkeit des Preisniveaus war die Bedingung, die in
beiden Vorversionen fehlte. Ein Inseratsportal liefert sie täglich neu. Damit
wird auch das Bewertungskriterium „übersteht die Pipeline Datenänderungen"
prüfbar statt behauptet.

**Preis dieser Entscheidung.** Das Thema ist sozialpolitisch unangenehm — ein
Vermieter, der Mieten ausreizt. Ausdrücklich in Kauf genommen. Was das Projekt
nicht tut: es nutzt keine Daten über echte Personen (E11) und behauptet nicht,
das Ergebnis sei wünschenswert.

**Revisionspunkt.** Wenn im Zielsegment 80–100 m² dauerhaft weniger als acht
Inserate je Bezirk und Abruf stehen, trägt die Marktseite die Entscheidung
nicht.

---

## E04 {#e04}
### Entscheidungsträger ist die Leitung Asset Management, nicht eine Behörde
**Phase:** Zuschnitt

**Situation.** Dieselbe Frage wie in E02: wer entscheidet was?

**Alternativen.**
1. Vermieter entscheidet je Vertrag über den Verlängerungspreis.
2. Gesetzgeber entscheidet über die Indexierungsgrenze.
3. Mieter entscheidet über Annahme oder Auszug.

**Entscheidung.** Variante 1.

**Begründung.** (2) wäre eine Politikfolgenabschätzung mit Daten, die wir nicht
haben. (3) ist keine Entscheidung mit Datengrundlage, sondern Verhalten — und
geht als modellierte Reaktion in (1) ein. (1) hat einen Adressaten mit Namen und
Rolle, einen Termin (Vertragsende) und echte Optionen: verlängern zu X,
verlängern zu Y, auslaufen lassen.

**Revisionspunkt.** Wenn die Empfehlung unabhängig von den Daten immer dieselbe
Option wäre, ist es keine Entscheidung (vgl. E17).

---

## E05 {#e05}
### Einkommensdaten sind Annahme- und Risikogröße, nicht Preisargument
**Phase:** Zuschnitt

**Situation.** Erste Fassung: das Portfolio ist an gutverdienende Berufsgruppen
vermietet, deren Kollektivvertragsabschlüsse öffentlich sind — also Miete an
Lohnentwicklung koppeln.

**Alternativen.**
1. Lohnabschluss als Begründung des Mietzinses („ihr Gehalt ist gestiegen").
2. Lohnabschluss als Einflussgröße auf Annahmewahrscheinlichkeit und
   Ausfallrisiko.

**Entscheidung.** Variante 2.

**Begründung.** (1) ist rechtlich nicht anschlussfähig: der Mietzins bemisst
sich am Objekt und der vertraglichen Wertsicherung, nicht am Einkommen des
Mieters. Als Prognosegröße für Zahlungsfähigkeit und Umzugsbereitschaft ist die
Lohnentwicklung dagegen genau das Richtige — und wird damit zu einer Größe, die
das Modell braucht, aber nicht sicher kennt.

**Wichtige Unschärfe, die daraus folgt.** Der Tariflohnindex misst
**Mindestlöhne** nach Kollektivvertrag, nicht Ist-Löhne einschließlich
Überzahlung. Bei Berufsgruppen mit hoher Überzahlung (IT) ist er ein schlechter
Schätzer, im öffentlichen Dienst ein guter. `config/berufsgruppen.json` führt
diesen Unschärfegrad je Gruppe mit; er ist die wichtigste bekannte Schwäche des
Modells und gehört in die Entscheidungsvorlage.

**Revisionspunkt.** Sobald eine Ist-Lohn-Reihe je Branche verfügbar ist, ersetzt
sie den Tariflohnindex.

---

## E06 {#e06}
### Manuelle Beschaffung statt automatisiertem Abruf
**Phase:** Datenzugriff · belegt 25.09.2026

**Situation.** Das Portal hat keine offene API. Die `robots.txt` untersagt im
Kopfkommentar ausdrücklich jeden automatisierten Zugriff und ist damit eine
maschinenlesbare Nutzungsvorbehaltserklärung.

**Alternativen.**
1. Crawler bauen und den Vorbehalt ignorieren.
2. Ein Mensch speichert die Seite, die Pipeline verarbeitet die Datei.
3. Thema wechseln (erneut).

**Entscheidung.** Variante 2.

**Begründung.** (1) ist nicht verhandelbar — und für die Bewertung nichts wert,
weil der automatisierte Teil ohnehin erst nach dem Abruf beginnt. (3) wäre der
vierte Themenwechsel. (2) kostet einen dokumentierten manuellen Schritt und
liefert dafür einen Datenstand, dessen Herkunft über SHA256 nachweisbar ist.
Dass mein eigener Abrufversuch am Botschutz scheiterte, bestätigt die
Einschätzung eher als sie zu widerlegen.

**Zugehörige Korrektur.** Ich hatte zunächst behauptet, die `robots.txt`
blockiere nur Filterparameter — Quelle war die Dokumentation eines
Scraping-Anbieters, also eine interessierte Zusammenfassung. Die archivierte
Datei (`docs/willhaben_robots_2026-09-25.txt`) sagt etwas anderes. Die
Korrektur steht in `02_schritt1_datenzugriff.md`.

**Revisionspunkt.** Wenn das Portal eine dokumentierte API mit
Nutzungsbedingungen anbietet, entfällt der manuelle Schritt.

---

## E07 {#e07}
### `__NEXT_DATA__` parsen statt HTML-Struktur
**Phase:** Datenzugriff

**Situation.** Die gespeicherte Seite enthält die Inserate zweimal: als
gerendertes HTML und als JSON im Script-Tag `__NEXT_DATA__`.

**Alternativen.**
1. HTML mit CSS-Selektoren auslesen.
2. Das JSON auslesen.

**Entscheidung.** Variante 2, Pfad
`props.pageProps.searchResult.advertSummaryList.advertSummary[]`.

**Begründung.** Die CSS-Klassen sind generierte Hashes (`Box-sc-wfmb7k-0
jiBisN`) und ändern sich bei jedem Deploy des Portals. Ein Parser darauf ist bei
der nächsten Produktänderung still kaputt. Die JSON-Feldnamen (`PRICE`,
`ESTATE_SIZE`, `ISPRIVATE`) sind Teil der Anwendungsschnittstelle und stabiler.
Zusätzlich liefert das JSON Felder, die im HTML nicht stehen — etwa
`ISPRIVATE`, das für E11 die entscheidende Unterscheidung trägt.

**Revisionspunkt.** `test_eur_pro_m2_des_portals_stimmt_mit_eigener_rechnung`:
wenn das Portal Feldbedeutungen ändert, fällt der Test, nicht die Zahl.

---

## E08 {#e08}
### Abrufzeitpunkt kommt vom Server, nicht von der Uhr des Parsers
**Phase:** Datenzugriff

**Situation.** Jede Beobachtung braucht einen Zeitstempel. Naheliegend wäre
`datetime.now()` beim Verarbeiten.

**Alternativen.**
1. Verarbeitungszeitpunkt.
2. `searchDate` aus der Antwort des Servers.

**Entscheidung.** Variante 2.

**Begründung.** Mit (1) bekommt dieselbe Datei bei jeder Verarbeitung einen
neuen Zeitstempel — der zweite Lauf hätte einen anderen Datenstand als der
erste, und die Zeitreihe würde den Zeitpunkt der Verarbeitung statt den der
Beobachtung messen. (2) ist eine Eigenschaft der Daten, nicht des Laufs.

**Revisionspunkt.** `test_abrufzeit_kommt_vom_server_nicht_vom_parser` und
`test_zweiter_lauf_liefert_dieselben_zahlen`.

---

## E09 {#e09}
### PLZ aus dem Dateinamen ist Pflichtprüfung, nicht Option
**Phase:** Datenzugriff · Vorfall 25.09.2026

**Situation.** Drei gelieferte Schnappschüsse waren byte-identisch
(SHA256 `a2ca0e8b…`), obwohl sie nach drei verschiedenen Bezirken benannt
waren — und alle drei enthielten Marktplatzdaten statt Immobilien:
`verticalId: 5`, 13.353.029 Treffer.

**Ursache.** `__NEXT_DATA__` wird bei clientseitiger Navigation innerhalb der
Next.js-App **nicht** aktualisiert. Wer sich durch die Seite klickt und dann
speichert, speichert den serverseitig gerenderten Erstaufruf. Nur ein
vollständiger Seitenaufruf (URL eingeben, Enter) erzeugt frisches
`__NEXT_DATA__`.

**Alternativen.**
1. Prüfung als optionaler Parameter (`erwartete_plz=…`), aufrufbar bei Bedarf.
2. Prüfung immer, PLZ aus der Namenskonvention `wh_<plz>_<suche>_<datum>.json`.

**Entscheidung.** Variante 2.

**Begründung.** Eine Prüfung, die man einschalten muss, ist an dem Tag aus, an
dem sie gebraucht wird. Der Dateiname ist die einzige vom Dateiinhalt
**unabhängige** Aussage darüber, was die Datei zeigen soll — genau deshalb
taugt er als Prüfgröße. Zusätzlich schlägt ein wiederkehrender SHA256 Alarm.

**Revisionspunkt.** `test_gate_meldet_plz_abweichung`, `test_gate_faengt_falsche
_seite_ab` gegen `data/sample/negativ_falscher_vertical.json`. Die Negativdatei
bleibt bewusst im Repository: sie ist gültiges JSON und hätte ohne Gate
schweigend einen Median über Gebrauchtwaren geliefert.

---

## E10 {#e10}
### Selbstprüfendes Beschaffungsskript statt schriftlicher Anleitung
**Phase:** Datenzugriff

**Situation.** Nach E09 war klar: die Fehlerquelle sitzt vor der Pipeline, im
manuellen Schritt. Ein Gate, das erst hinterher ablehnt, kostet einen ganzen
Beschaffungsdurchgang.

**Alternativen.**
1. Schritt-für-Schritt-Anleitung in der Dokumentation.
2. Konsolenskript, das die Prüfungen vor dem Speichern selbst ausführt und den
   Dateinamen aus den Daten bildet.

**Entscheidung.** Variante 2 (`tools/snapshot.js`), zusätzlich zur Anleitung.

**Begründung.** Das Skript prüft genau das, was in E09 schiefging —
`verticalId`, Trefferzahl, PLZ-Anteil, URL gegen Daten — und bricht mit
benanntem Grund ab. Der Dateiname entsteht aus dem Inhalt, nicht aus dem
Gedächtnis. Damit ist die Prüfung dort, wo der Fehler entsteht, und das Gate
wird zur zweiten Verteidigungslinie statt zur ersten.

**Revisionspunkt.** Wenn wieder eine Datei am Gate scheitert, hat das Skript
seinen Zweck verfehlt — dann fehlt eine Prüfung darin.

---

## E11 {#e11}
### Allowlist statt Blocklist, durchgesetzt im Code
**Phase:** Datenschutz

**Situation.** Die Vorgabe verbietet personenbezogene Daten ausnahmslos. Die
Inseratsdaten enthalten reichlich davon, teils nicht offensichtlich:
`ORGNAME` ist formal ein Firmenname, trägt aber häufig Personennamen
(„MMI Mario Molnar Immobilienberatung", „Realbüro Dr. C. Huber"), dazu
Anbieterkennungen, Freitexte und punktgenaue Koordinaten.

**Alternativen.**
1. Blocklist: bekannte Problemfelder verwerfen.
2. Allowlist: nur ausdrücklich erlaubte Felder behalten.
3. Filterung im LLM-Prompt beschreiben.

**Entscheidung.** Variante 2, 18 erlaubte Felder in `config.PII_ERLAUBT`,
Verwerfungsgründe in `config.PII_VERWORFEN`.

**Begründung.** (1) lässt jedes neue Feld des Portals stillschweigend durch —
die Richtung ist falsch. (3) ist keine Zusicherung, sondern eine Bitte; ein
Prompt ist nicht prüfbar und nicht testbar. (2) versagt im Zweifel zur
sicheren Seite: ein unbekanntes Feld fliegt raus und fällt dadurch auf.
Behalten wird von der Anbieterseite nur `ISPRIVATE` — privat oder gewerblich
ist eine Analysegröße (der gewerbliche Median liegt 16 % über dem privaten),
und das Flag benennt niemanden.

**Revisionspunkt.** `test_kein_pii_in_bereinigten_zeilen` und die
Kontrollsuche in `clean.pii_kontrolle` als letzte Instanz vor dem Schreiben.
Ein Treffer dort ist ein Fehler, keine Warnung.

---

## E12 {#e12}
### SQLite statt MySQL-Server
**Phase:** Datenmodell

**Situation.** Ursprünglich war ein MySQL-Server angedacht.

**Alternativen.**
1. MySQL-Server.
2. SQLite als Datei im Projekt.

**Entscheidung.** Variante 2.

**Begründung.** Die Datenmengen sind klein (Hunderte Zeilen je Abruf). Ein
Server verlangt Installation, Zugangsdaten und einen laufenden Prozess — und
macht den Zustand der Datenbank zu etwas, das im Repository nicht steht. Mit
SQLite ist die Datenbank ein erzeugtes Artefakt: `python3 -m src.run` genügt,
auf jedem Rechner, ohne Zugangsdaten. Das SQL bleibt Standard-SQL; der Umzug auf
einen Server wäre eine Konfigurationsänderung.

**Preis.** Kein `PERCENTILE_CONT` (→ E16), keine parallelen Schreibzugriffe.

**Revisionspunkt.** Wenn die Datenbank mehrere Nutzer gleichzeitig bedienen
soll oder Millionen Zeilen hält.

---

## E13 {#e13}
### Faktentabelle append-only, Schlüssel (Schnappschuss, Inserat)
**Phase:** Datenmodell

**Situation.** Derselbe Inseratsschlüssel erscheint in aufeinanderfolgenden
Abrufen erneut, teils mit geändertem Preis.

**Alternativen.**
1. Primärschlüssel `ad_id`, Zeile beim Wiedersehen aktualisieren.
2. Primärschlüssel `(snapshot_id, ad_id)`, nie aktualisieren.

**Entscheidung.** Variante 2.

**Begründung.** (1) wirft genau die Information weg, die zwei der drei Analysen
tragen: Preisänderung während der Laufzeit und Inseratsdauer. Mit (2) fallen
beide als Abfrage aus den Daten heraus, ohne eigene Erhebung — und die
Inseratsdauer ist zugleich der Schätzer für die Leerstandsannahme im
Entscheidungsmodell, die bisher geraten ist.

**Bekannte Komplikation.** Ein Inserat im jüngsten Schnappschuss seiner PLZ ist
noch offen; seine Dauer ist eine Untergrenze. `v_inseratsdauer` führt deshalb
die Spalte `zensiert`. Ein Mittelwert über zensierte Fälle unterschätzt
systematisch — der Kennzahl-Kommentar sagt das.

**Revisionspunkt.** Sobald zwei Schnappschüsse derselben PLZ vorliegen, müssen
`v_preisaenderung` und `v_inseratsdauer` Zeilen liefern. Heute sind sie leer,
und das ist kein Fehler, sondern der aktuelle Stand.

---

## E14 {#e14}
### PLZ als Fremdschlüssel, Bezirksliste in der Konfiguration
**Phase:** Datenmodell

**Situation.** Das Portfolio liegt in drei Bezirken, zwei weitere dienen als
Referenz. Es sollen Bezirke hinzukommen können.

**Alternativen.**
1. Bezirk als Text in der Beobachtungszeile.
2. Tabelle `bezirk` mit PLZ als Schlüssel, Zuordnung aus `config.BEZIRKE`.

**Entscheidung.** Variante 2, Views durchgehend nach PLZ gruppiert.

**Begründung.** Ein neuer Bezirk ist damit eine Datei mehr und ein Eintrag in
der Konfiguration — kein Eingriff in Views oder Code. Zugleich wird eine
unbekannte PLZ sichtbar statt still: sie landet in `zuordnungsluecke` und wird
gezählt. Eine Textspalte hätte den Fall stumm geschluckt.

**Revisionspunkt.** `test_jede_beobachtung_haengt_an_einem_bezirk`;
`v_abdeckung` zeigt je Bezirk „noch nicht beschafft" statt gar nichts.

---

## E15 {#e15}
### Die Datenbank wird bei jedem Lauf neu gebaut
**Phase:** Datenmodell

**Situation.** Reproduzierbarkeit war Abnahmekriterium: zwei Läufe, dieselben
Zahlen.

**Alternativen.**
1. Inkrementell laden, nur neue Schnappschüsse ergänzen.
2. Datenbank löschen und aus **allen** Rohordnern neu aufbauen.

**Entscheidung.** Variante 2.

**Begründung.** Bei (1) hängt das Ergebnis von der Reihenfolge der Läufe ab,
und ein Fehler von vorgestern bleibt in der Datenbank, auch wenn der Code
repariert ist. Bei (2) ist `data/raw/` die Quelle der Wahrheit und die Datenbank
ein jederzeit verwerfbares Ergebnis. Die Kosten sind bei dieser Datenmenge
irrelevant (Laufzeit unter zwei Sekunden).

**Revisionspunkt.** `test_zweiter_lauf_liefert_dieselben_zahlen`. Bei
Datenmengen, bei denen ein Neuaufbau Minuten dauert, kippt die Abwägung —
dann braucht es (1) plus einen Prüflauf, der (2) nachrechnet.

---

## E16 {#e16}
### Median über Fensterfunktion, Fallzahl an jeder Aggregatzeile
**Phase:** Analyse

**Situation.** SQLite kennt kein `PERCENTILE_CONT` (Folge von E12).

**Alternativen.**
1. Mittelwert statt Median.
2. Aggregation in Python (pandas).
3. Median in SQL über `ROW_NUMBER()` und `COUNT()` als Fensterfunktionen.

**Entscheidung.** Variante 3.

**Begründung.** (1) ist bei Mietinseraten irreführend: einzelne möblierte
Kurzzeitangebote mit 60 €/m² ziehen den Mittelwert, nicht den Median. (2) würde
die Vorgabe brechen, dass jede Zahl der Entscheidungsvorlage aus einer
SQL-Abfrage kommt und diese nennt. (3) hält die Zahl im SQL und ist prüfbar.

**Zweite Entscheidung im selben Zug.** Jede Aggregatzeile führt ihre Fallzahl
und eine Belastbarkeitsstufe mit (n≥15 belastbar, n≥8 dünn, sonst nicht
belastbar). Ein Median über vier Inserate sieht in einer Tabelle genauso aus wie
einer über vierzig. Ohne die Fallzahl **in derselben Zeile** wird die
Unsicherheit beim Weiterverwenden abgeschnitten — besonders, wenn ein
Sprachmodell die Zeile in Prosa übersetzt.

**Revisionspunkt.** `test_median_liegt_zwischen_min_und_max`,
`test_fallzahl_steht_an_jeder_aggregatzeile`.

---

## E17 {#e17}
### Jedes Entscheidungsmodell braucht eine Gegenkraft
**Phase:** Modell

**Situation.** Im Greifenstein-Modell war die Empfehlung ausnahmslos das
größte Stauzielband — das Modell hatte keinen Grund, je etwas anderes zu sagen.
Im Mietmodell drohte dasselbe: ohne Gegenkraft ist die optimale Miete immer die
höchste.

**Alternativen.**
1. Zielgröße ohne Gegenkraft, Grenzen extern setzen.
2. Gegenkräfte ins Modell: Annahmewahrscheinlichkeit, Leerstandskosten,
   Ausfallrisiko oberhalb einer Belastungsschwelle.

**Entscheidung.** Variante 2.

**Begründung.** Ein Modell, dessen Empfehlung nicht von den Daten abhängt, ist
keine Entscheidungsunterstützung, sondern eine Meinung mit Nachkommastellen.
Erst mit Gegenkraft entsteht ein inneres Optimum — und damit überhaupt eine
Aussage, die sich mit neuen Daten ändern kann.

**Revisionspunkt.** `test_bei_kleiner_luecke_liegt_optimum_im_inneren`,
`test_grosse_luecke_fuehrt_zu_marktmiete`,
`test_umzugstraegheit_hilft_dem_vermieter`. Fällt das Optimum in allen Fällen
auf den Rand des Angebotsrasters, ist die Gegenkraft zu schwach parametrisiert.

---

## E18 {#e18}
### Portfolio-Fixpunkt mit Dämpfung statt Einmalrechnung
**Phase:** Modell

**Situation.** Wer fünfzig ähnliche Wohnungen gleichzeitig anbietet, ist sein
eigener Wettbewerber: die eigenen Angebote senken das Preisniveau, gegen das
sie gerechnet werden.

**Alternativen.**
1. Marktmiete als gegeben nehmen, Selbstkonkurrenz ignorieren.
2. Fixpunkt iterieren, bis Angebot und angenommenes Marktniveau zusammenpassen.

**Entscheidung.** Variante 2.

**Begründung.** (1) überschätzt den erzielbaren Preis genau dann, wenn viele
Verträge gleichzeitig auslaufen — also im Anwendungsfall.

**Was schiefging und wie es behoben ist.** Die erste Iteration pendelte
zwischen zwei Zuständen bis zum Abbruch nach der Höchstzahl an Runden. Mit
50/50-Dämpfung konvergiert sie in zwei Runden. Nicht-Konvergenz wird jetzt
gemeldet statt verschwiegen — ein stiller Abbruch nach `MAX_ITER` hätte ein
Zwischenergebnis als Ergebnis ausgegeben.

**Revisionspunkt.** Meldet der Lauf Nicht-Konvergenz, darf keine Vorlage
entstehen.

---

## E19 {#e19}
### PII-Logik in `clean.py`, Allowlist in `config.py` — ein Ort je Sache
**Datum:** 25.09.2026

**Situation.** Nach dem Umbau auf die vorgegebene Repository-Struktur gab es die
Allowlist zweimal: in `src/pii.py` und in `src/config.py`, mit identischem
Inhalt und zwei Prüffunktionen, die dasselbe taten.

**Alternativen.**
1. `pii.py` als Modul behalten, `config.py` importiert daraus.
2. `pii.py` auflösen: Allowlist und Verwerfungsgründe in `config.py`, Filter und
   Kontrollsuche in `clean.py` (Schritt 2, wo die Daten durchlaufen).

**Entscheidung.** Variante 2. `src/pii.py` entfernt, `redigiere_text` nach
`clean.py` übernommen.

**Begründung.** Zwei Fassungen derselben Liste laufen auseinander, sobald eine
gepflegt wird. Die Konfiguration gehört dorthin, wo auch Quellen, Bezirke und
Schwellen stehen; die Logik gehört in den Pipeline-Schritt, der sie anwendet.
`redigiere_text` bleibt, obwohl die Allowlist alle Freitextfelder verwirft — für
die unstrukturierten Quellen (Kollektivvertrags- und Gesetzestexte), die in den
LLM-Schritt gehen.

**Nebenbefund derselben Sitzung.** Gate 2 schlug bei einem eigenen technischen
Feld an: der Schnappschussname `wh_1020_…_2026-09-25T1555.json` traf das
Telefonmuster. Behoben durch Ausnahme **des Feldes** (`PII_UNVERDAECHTIG`), nicht
durch Aufweichen des Musters — ein lockereres Muster findet die echten Fälle
nicht mehr.

**Revisionspunkt.** `grep -rn "ERLAUBT" src/` darf genau eine Definition
finden.

---

## E20 {#e20}
### GitHub-Repository als gemeinsame Arbeitsfläche
**Datum:** 25.09.2026

**Situation.** Die Lehrveranstaltung verlangt ein Repository mit Historie und
Abgabe-Tags (`termin3`, `termin4`). Bisher lag das Projekt nur im
Arbeitsverzeichnis dieser Sitzung — das verfällt.

**Alternativen.**
1. Dateien als Anhang hin und her schicken, Nutzer committet selbst.
2. Repository auf GitHub, in dieser Sitzung freigegeben; ich committe und pushe
   direkt.
3. Lokales Git im Container ohne Fernkopie.

**Entscheidung.** Variante 2, mit (3) als sofortigem Zwischenschritt: das
lokale Repository ist angelegt und hat einen ersten Commit, damit die Historie
ab jetzt entsteht und nicht am Ende rekonstruiert wird.

**Begründung.** (1) erzeugt Commits ohne Bezug zu den Arbeitsschritten — genau
die „am Ende rekonstruierte" Historie, die die Bewertung abstraft. (3) allein
verfällt mit dem Container.

**Bedingung, die der Nutzer erfüllen muss.** Ein Push braucht das Repository in
den freigegebenen Quellen dieser Sitzung; die Zugangsdaten setzt der Proxy
dann selbst ein. Ein Token im Chat wäre ein Geheimnis im Klartext und wird
nicht verwendet.

**Revisionspunkt.** Wenn Commits nur zu Abgabeterminen entstehen, ist die
Historie wieder eine Rekonstruktion.

---

## E21 {#e21}
### Im Repository liegen redigierte Schnappschüsse, die Originale bleiben lokal
**Datum:** 25.09.2026

**Situation.** Unmittelbar vor dem ersten Push geprüft, was die gespeicherte
Seite eigentlich enthält. Zwei Funde: `dmpUserIdentities.wh_uuid` — eine Kennung
des Browsers, mit dem gespeichert wurde — und die vollständigen
Anbieterangaben inklusive Firmennamen mit Personennamen darin.

**Warum das dringend war.** Ein Push ist unumkehrbar. `git rm` entfernt eine
Datei aus dem Arbeitsstand, nicht aus der Historie; danach hilft nur noch
History-Rewrite, und in einem geteilten Repository auch das schlecht. Die
Vorgabe lautet: keine personenbezogenen Daten, nirgends.

**Alternativen.**
1. Repository privat halten und die Rohdatei unverändert committen.
2. Rohdaten nicht committen. Dann läuft `python3 -m src.run` im frischen Klon
   ins Leere — das Abnahmekriterium wäre nicht prüfbar.
3. Werte der nicht benötigten Felder durch `[ENTFERNT]` ersetzen, Struktur und
   Feldnamen erhalten, Originale lokal behalten.

**Entscheidung.** Variante 3 (`tools/redigiere_schnappschuss.py`).

**Begründung.** (1) verlagert eine Datenschutzfrage auf eine
Sichtbarkeitseinstellung; ein einziges Umschalten auf „public" macht sie wieder
auf, und für die Bewertung wäre ein Repository, das nur wegen seiner
Privatheit vorgabenkonform ist, keine gute Antwort. (2) kostet genau das, was
dieses Projekt auszeichnet: dass die Pipeline bei jedem nachvollziehbar läuft.
(3) behält Lauffähigkeit und Nachvollziehbarkeit und gibt nichts weiter.

Feldnamen bleiben absichtlich stehen. Sie belegen, was die Quelle liefert — und
damit, warum die Allowlist aus E11 nötig ist — ohne den Inhalt zu verbreiten.
`advertiserInfo.label` wird auf `Privat` / `[GEWERBLICH]` reduziert statt
entfernt, weil der Parser daraus eine Analysegröße gewinnt (der gewerbliche
Median liegt 16 % über dem privaten) und das Flag niemanden benennt.

**Beleg, dass nichts verlorenging.** Das Werkzeug prüft selbst, dass der Parser
aus beiden Fassungen dasselbe liest. Stärker noch: die fünf Kennzahl-CSV sind
vor und nach der Redaktion bit-identisch. Beide SHA256 stehen in
`data/raw/2026-09-25/HERKUNFT.md`.

**Preis dieser Entscheidung.** Wer die Rohdaten unabhängig nachprüfen will,
braucht das Original vom Menschen, der es gespeichert hat. Das ist der Preis,
und er wird benannt statt verschwiegen.

**Revisionspunkt.** Wenn eine neue Quelle Felder liefert, die
`tools/redigiere_schnappschuss.py` nicht kennt, werden deren Werte entfernt —
die Redaktion versagt also zur sicheren Seite. Kommt ein Feld hinzu, das die
Pipeline BRAUCHT, meldet die Selbstprüfung des Werkzeugs abweichende Lesung.

---

## E22 {#e22}
### `verticalId` ist die erste Prüfung in Gate 1
**Datum:** 25.09.2026

**Situation.** Gate 1 fing die Marktplatzdatei über Trefferzahl und
PLZ-Streuung ab — beides Indizien. Die Rubrikkennung `verticalId` lag in den
Daten, wurde aber nur vom Beschaffungsskript geprüft, nicht vom Gate.

**Alternativen.**
1. Bei den Indizien bleiben; sie haben im Vorfall funktioniert.
2. `verticalId` in den Schnappschuss aufnehmen und als erste Prüfung setzen.

**Entscheidung.** Variante 2.

**Begründung.** Die Indizien funktionierten zufällig gut: eine Marktplatzsuche
nach einem seltenen Begriff hätte eine plausible Trefferzahl und wenige PLZ —
und wäre durchgekommen. `verticalId` ist keine Ableitung, sondern die Aussage
des Portals selbst, um welche Rubrik es sich handelt. Eine Prüfung, die direkt
misst, gehört vor eine, die schließt.

**Revisionspunkt.** `test_gate_faengt_falsche_seite_ab` verlangt jetzt auch
den Befund „richtige Rubrik".

---

## E23 {#e23}
### `datenbeschaffung.md` wird die Schrittdokumentation, nicht ihr Nachbar
**Datum:** 25.09.2026

**Situation.** Die Lehrveranstaltung gibt `docs/projektdokumentation/02_schritt1_
datenzugriff.md` vor. Zum Datenzugriff existierte bereits `docs/
datenbeschaffung.md` mit Rechtslage, Vorfällen und PII-Abschnitt.

**Alternativen.**
1. Beides behalten: die Schrittdokumentation fasst zusammen und verweist.
2. Die bestehende Datei umbenennen und um das ergänzen, was der Schritt
   verlangt — Frage des Schritts, Abnahmekriterium, Quellentabelle.

**Entscheidung.** Variante 2, `git mv` samt Anpassung aller sechs Verweise.

**Begründung.** Zwei Dokumente zum selben Gegenstand laufen auseinander, sobald
eines gepflegt wird — dieselbe Erfahrung wie bei der doppelten Allowlist (E19).
Eine Zusammenfassung, die niemand nachzieht, ist schlechter als kein zweites
Dokument. `git mv` erhält zudem die Historie der Datei.

**Revisionspunkt.** Außerhalb dieses Logs darf der alte Dateiname nirgends
mehr vorkommen: `grep -rn "datenbeschaffung.md" --exclude=01_entscheidungslog.md`
bleibt leer.

---

## E24 {#e24}
### Claude bleibt Autor der Commits
**Datum:** 25.09.2026

**Situation.** Die Commits laufen auf `Claude <noreply@anthropic.com>`. Für eine
bewertete Abgabe war zu klären, wer als Autor erscheint.

**Alternativen.**
1. Der Studierende als Autor, Claude als `Co-Authored-By`. GitHub ordnet die
   Commits dann seinem Profil zu.
2. Claude als Autor, wie bisher.

**Entscheidung.** Variante 2, auf ausdrücklichen Wunsch.

**Begründung des Nutzers.** Nicht weiter ausgeführt; die Entscheidung liegt bei
ihm. Festzuhalten ist die Konsequenz: die Autorenzeile der Historie belegt
keinen eigenen Beitrag. Was von wem kam, ist stattdessen hier im
Entscheidungslog nachvollziehbar — die Themenwahl, die drei Wechsel, der
Zuschnitt auf den Vermieter, der Verzicht auf das Einkommensargument und die
Freigabe der dystopischen Prämisse sind Entscheidungen des Studierenden, nicht
Vorschläge des Modells.

**Revisionspunkt.** Umkehrbar für künftige Commits durch eine Änderung von
`user.name`/`user.email`; die bestehenden Commits blieben davon unberührt.

---

## E25 {#e25}
### `data/raw/` wird committet — begründete Abweichung von der Vorgabe
**Datum:** 25.09.2026

**Situation.** Die Vorgabe sagt zu Schritt 1: *„Im Repo danach: nichts.
`data/raw/` ist gitignored."* Im Beispielprojekt liegen die Quelldaten
stattdessen in `data/sample/` und sind committet — dort sind sie **synthetisch**
erzeugt (`src/synth/`). Unsere Schnappschüsse sind echte Marktdaten.

**Alternativen.**
1. Vorgabe wörtlich: `data/raw/` ignorieren. Dann läuft `python3 -m src.run` im
   frischen Klon ins Leere.
2. Die redigierten Schnappschüsse nach `data/sample/` verschieben, wie im
   Beispiel, und `data/raw/` ignorieren.
3. `data/raw/` mit den **redigierten** Fassungen committen, die unredigierten
   Originale ignorieren.

**Entscheidung.** Variante 3.

**Begründung.** (1) widerspricht der Vorgabe an anderer Stelle: Schritt 5
verlangt, *„das Repo in ein neues Verzeichnis zu klonen und nur der README zu
folgen"*. Ein Klon ohne Daten kann das nicht. (2) wäre die Vorgabe
buchstabengetreu, würde aber echte Daten als Beispieldaten ausweisen — im
Beispielprojekt heißt `data/sample/` „synthetisch erzeugt", und diese Bedeutung
zu überschreiben wäre eine Verschleierung der Herkunft. Der Ordnername ist eine
Aussage über die Daten.

Der Zweck des Vorgabesatzes ist erfüllt: der Grund für das Ignorieren von
`data/raw/` sind Personenbezug und Dateigröße. Beides trifft auf die redigierten
Fassungen nicht zu (E21, 494 kB). Die unredigierten Originale sind ignoriert.

**Revisionspunkt.** Landet je eine unredigierte Datei unter `data/raw/`, ist die
Entscheidung verletzt. Schutz: `tools/redigiere_schnappschuss.py` als Pflicht
vor dem Commit (CLAUDE.md, Regel 1) und die PII-Kontrolle in Gate 2.

---

## E26 {#e26}
### Die Datenbank wird committet, also darf keine Uhrzeit darin stehen
**Datum:** 25.09.2026

**Situation.** Die Vorgabe zu Schritt 3 verlangt, `data/processed/<projekt>.sqlite`
zu committen. Bisher war sie ignoriert, mit dem Argument aus E15: die Datenbank
ist ein Ergebnis, kein Quellbestand.

**Der Haken, der beim Prüfen auffiel.** `qs_befund` trug einen
`lauf_ts` aus `datetime.now()`. Eine committete Datenbank mit einer Uhrzeit darin
erzeugt bei **jedem** Lauf einen Diff — und widerlegt genau die Aussage, mit der
E15 begründet ist.

**Alternativen.**
1. Datenbank weiter ignorieren, entgegen der Vorgabe.
2. Datenbank committen und den Diff bei jedem Lauf hinnehmen.
3. Datenbank committen und die Uhrzeit entfernen: der Befund trägt den
   **Datenstand**, zu dem er gehört (`abruf_ts` des Schnappschusses).

**Entscheidung.** Variante 3. Spalte `lauf_ts` → `datenstand`.

**Begründung.** Der Nutzen der Vorgabe ist echt: wer das Repository bewertet,
kann die Datenbank mit DB Browser for SQLite öffnen, ohne etwas auszuführen.
(2) hätte diesen Nutzen mit Diff-Rauschen bezahlt und den Anspruch der
Reproduzierbarkeit unterlaufen. Der Zeitpunkt eines Qualitätsbefunds ist
inhaltlich ohnehin der Datenstand, nicht die Uhrzeit des Laufs — die Änderung
macht die Tabelle also auch richtiger.

E15 bleibt gültig: `data/raw/` ist die Quelle der Wahrheit, die Datenbank wird
bei jedem Lauf gelöscht und neu gebaut. Sie ist jetzt zusätzlich **byteweise**
dasselbe Ergebnis.

**Revisionspunkt.** `test_datenbank_ist_byteweise_reproduzierbar` baut die
Datenbank zweimal mit über einer Sekunde Abstand und vergleicht den SHA256.
Kommt je wieder ein Wert aus der Uhr in die Datenbank, fällt der Test.
